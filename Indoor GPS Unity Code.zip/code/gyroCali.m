clear;
clc;
mCSV = importdata('state.csv');
t = mCSV.data(:,1);
xSpd = mCSV.data(:,5);
ySpd = mCSV.data(:,6);
zSpd = mCSV.data(:,7);
figure(1);
plot(t,xSpd);
hold on;
figure(2);
plot(t,ySpd);
hold on;
figure(3);
plot(t,zSpd);
hold on;
mean(xSpd)
mean(ySpd)
mean(zSpd)
