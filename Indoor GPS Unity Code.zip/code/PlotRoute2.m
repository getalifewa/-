clear;
clc;
realtraceD = [2;2;2]; 
realtraceH = [180;270;0];
XAc = [0];
YAc = [0];
for i = 1 : length(realtraceD)
    XAc = [XAc; XAc(i) + realtraceD(i)*cosd(realtraceH(i))];
    YAc = [YAc; YAc(i) + realtraceD(i)*sind(realtraceH(i))];
end



DHFile = importdata('DirectHeadingdata2.csv');
distance = DHFile.data(:,1);
heading = DHFile.data(:,2);
XEst = [0];
YEst = [0];
for i = 1 : length(distance)
    XEst = [XEst; XEst(i) + 0.5*cosd(heading(i))];
    YEst = [YEst; YEst(i) + 0.5*sind(heading(i))];
end

plot(XAc,YAc,'-o');
hold on;
plot(XEst,YEst,'-*');
axis equal;

xlabel('$$X$$','Interpreter','latex')
ylabel('$$Y$$','Interpreter','latex')