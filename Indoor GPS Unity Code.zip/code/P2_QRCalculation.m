clear;
clc;
CaliFile = importdata('cali.csv');
Mag = CaliFile.data(:,8:10);
[Mag_Center,Mag_Scale] = fit_elliposoid9(Mag);

StateFile = importdata('state.csv');
t = StateFile.data(:,1);
xGyr = StateFile.data(:,5);
xM = StateFile.data(:,8);
yM = StateFile.data(:,9);
zM = StateFile.data(:,10);
xM = (xM - Mag_Center(1))/Mag_Scale(1);
yM = (yM - Mag_Center(2))/Mag_Scale(2);
zM = (zM - Mag_Center(3))/Mag_Scale(3);

angle = atand(xM./yM);
angle = angle(2:end);

Q = std(0.02*xGyr)
R = std(angle)