clear;
clc;
mCSV = importdata('90deg.csv');
t = mCSV.data(:,1);
xSpd = mCSV.data(:,5);
ySpd = mCSV.data(:,6);
zSpd = mCSV.data(:,7);
figure(1);
plot(t,xSpd);
hold on;
figure(2);
plot(t,ySpd);
hold on;
figure(3);
plot(t,zSpd);
hold on;

GI = tf([1],[1,0])

figure(4);
xAng = lsim(GI, xSpd, t);
plot(t,xAng);

figure(4);
yAng = lsim(GI, ySpd, t);
plot(t,yAng);

figure(4);
zAng = lsim(GI, zSpd, t);
plot(t,zAng);

Gz = c2d(GI,0.02,'tustin');
Gz.variable = 'z^-1'