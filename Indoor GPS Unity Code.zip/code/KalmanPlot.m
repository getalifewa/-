clear;
clc;



DHFile = importdata('KalmanRotate.csv');
magheading = DHFile(:,1);
heading = DHFile(:,2);
length(heading)
t = 0:0.02:0.02*(length(heading)-1);

plot(t,magheading);
hold on;
plot(t,heading);

legend('$$\theta_{Mag}$$','$$\theta_{Kal} $$','Interpreter','latex')
xlabel('$$t$$','Interpreter','latex')
ylabel('$$\theta$$','Interpreter','latex')