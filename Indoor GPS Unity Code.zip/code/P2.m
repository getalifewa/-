clear;
clc;
mCSV = importdata('walk9.csv');
t = mCSV.data(:,1);
xAcc = mCSV.data(:,2);
yAcc = mCSV.data(:,3);
zAcc = mCSV.data(:,4);
figure(1);
plot(t,xAcc);
hold on;
figure(2);
plot(t,yAcc);
hold on;
figure(3);
plot(t,zAcc);
hold on;

GH = tf([1 0],[1 2*pi*1]);
GL = tf([2*pi*3],[1 2*pi*3]);
GF = GH;

GSS = tf([1] , [1 0 0])

xAcc_fix = lsim(GF , xAcc, t);
figure(1);
%plot(t,xAcc_fix);

xdis = lsim(GSS , 9.8*xAcc_fix(300:1235), t(300:1235));
plot(t(300:1235),xdis);

yAcc_fix = lsim(GF , yAcc, t);
figure(2);
%plot(t,yAcc_fix);

ydis = lsim(GSS , 9.8*yAcc_fix(300:1235), t(300:1235));
plot(t(300:1235),ydis);

zAcc_fix = lsim(GF , zAcc, t);
figure(3);
%plot(t,zAcc_fix);

zdis = lsim(GSS , 9.8*zAcc_fix(300:1235), t(300:1235));
plot(t(300:1235),zdis);

VAcc = sqrt(xAcc.^2+yAcc.^2+zAcc.^2);
VAcc_fix = lsim(GF , VAcc, t);
figure(4);
% plot(t,VAcc);

plot(t,VAcc_fix,'b');
hold on;
tp=0;
point = [];
pointt = [];
for i = 1:length(VAcc_fix)
    tp = tp + 0.02;
    if(tp > 0.3)
        if(VAcc_fix(i)>0.3 &&  VAcc_fix(i)>VAcc_fix(i-1) && VAcc_fix(i)>VAcc_fix(i+1))
            point = [point VAcc_fix(i)];
            pointt = [pointt t(i)];
            tp = 0;
        end
    end
end
% plot(pointt,point,'r*');

legend('$$Acc_{f}$$','$$Step$$','Interpreter','latex')
xlabel('$$t/s$$','Interpreter','latex')
ylabel('$$g$$','Interpreter','latex')

Gz = c2d(GF,0.02,'tustin');
Gz.variable = 'z^-1'
Gzss = c2d(GSS*GH,0.02,'tustin');
Gzss.variable = 'z^-1'