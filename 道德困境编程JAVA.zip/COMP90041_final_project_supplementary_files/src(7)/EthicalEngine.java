import ethicalengine.Argument;
import ethicalengine.Character;
import ethicalengine.Person;
import ethicalengine.Scenario;
import ethicalengine.ScenarioGenerator;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class EthicalEngine {

    public enum Decision {
        PEDESTRIANS, PASSENGERS
    }

    /**
     * @param ch
     * @return
     */
    private static int calcScore(Character ch) {
        int ret = 1;
        if (ch instanceof Person) {
            Person person = (Person) ch;
            if (person.isPregnant()) {
                ret += 5;
            }
            switch (person.getAgeCategory()) {
                case BABY:
                    ret += 3;
                    break;
                case CHILD:
                    ret += 2;
                    break;
                case ADULT:
                    ret += 1;
                    break;
                default:
                    break;
            }
            switch (person.getProfession()) {
                case DOCTOR:
                    ret += 2;
                    break;
                case CEO:
                    ret += 1;
                    break;
                case CRIMINAL:
                    ret -= 2;
                    break;
                case HOMELESS:
                    ret -= 1;
                    break;
                default:
                    break;
            }
        }
        return ret;
    }

    /**
     * decide who live
     *
     * @param scenario scenario to decide
     * @return PEDESTRIANS or PASSENGERS
     */
    public static Decision decide(Scenario scenario) {
        int passengersPoint = 0;
        int pedestrainsPoint = 0;


        for (Character ch : scenario.getPassengers()) {
            passengersPoint += calcScore(ch);
        }
        for (Character ch : scenario.getPedestrians()) {
            pedestrainsPoint += calcScore(ch);
        }
        if (!scenario.isLegalCrossing()) {
            passengersPoint -= scenario.getPassengerCount();
        } else {
            passengersPoint += scenario.getPassengerCount();
        }
        return pedestrainsPoint > passengersPoint ? Decision.PEDESTRIANS : Decision.PASSENGERS;
    }

    /**
     * display the contents of welcome.ascii
     *
     * @throws IOException
     */
    private static void printWelcome() throws IOException {
        try (InputStream res = EthicalEngine.class.getResourceAsStream("welcome.ascii")) {
            byte[] buf = new byte[res.available()];
            res.read(buf);
            System.out.println(new String(buf));
        }
    }

    /**
     * create scenario from config or generator
     *
     * @param cmd user command
     * @return scenarios
     * @throws IOException
     */
    private static Scenario[] genScenario(Argument cmd) throws IOException {
        if (cmd.getConfigFile() != null) {
            return cmd.getConfig();
        } else {
            Scenario[] ret = new Scenario[3];
            ScenarioGenerator generator = new ScenarioGenerator();
            for (int i = 0; i < ret.length; i++) {
                ret[i] = generator.generate();
            }
            return ret;
        }
    }

    /**
     * user decision
     *
     * @return PEDESTRIANS or PASSENGERS
     */
    private static Decision userDecision(Scanner scanner) {
        while (true) {
            System.out.println("Who should be saved? (passenger(s) [1] or pedestrian(s) [2])");
            String userResponse = scanner.nextLine().trim();
            if (userResponse.equalsIgnoreCase("passenger") ||
                userResponse.equalsIgnoreCase("passengers") ||
                userResponse.equalsIgnoreCase("1")) {
                return Decision.PASSENGERS;
            } else if (userResponse.equalsIgnoreCase("pedestrian") ||
                userResponse.equalsIgnoreCase("pedestrians") ||
                userResponse.equalsIgnoreCase("2")) {
                return Decision.PEDESTRIANS;
            }
        }
    }

    /**
     * ask user they want save result or not
     *
     * @return save or not
     */
    private static boolean saveDecisionToFile(Scanner scanner) {
        System.out.println("Do you consent to have your decisions saved to a file? (yes/no)");
        while (true) {
            String userResponse = scanner.nextLine().trim();
            if (userResponse.equalsIgnoreCase("yes")) {
                return true;
            } else if (userResponse.equalsIgnoreCase("no")) {
                return false;
            } else {
                System.out.println("Invalid response. Do you consent to have your decisions saved to a file? (yes/no)");
            }
        }
    }

    /**
     * ask user if they want to exit
     *
     * @return quit or not
     */
    private static boolean continueOrNo(Scanner scanner) {
        while (true) {
            System.out.println("Would you like to continue? (yes/no)");
            String userResponse = scanner.nextLine().trim();
            if (userResponse.equalsIgnoreCase("yes")) {
                return true;
            } else if (userResponse.equalsIgnoreCase("no")) {
                return false;
            }
        }
    }

    /**
     * "-i" interactive mode
     *
     * @param audit
     * @param cmd
     * @throws IOException
     */
    private static void interactiveMode(Audit audit, Argument cmd, Scanner scanner) throws IOException {
        audit.setAuditType("interactive");
        audit.setDecisionFun(scenario -> userDecision(scanner));
        while (true) {
            Scenario[] curScenario = genScenario(cmd);
            for (int idx = 0 ; idx < curScenario.length ; idx ++) {
                System.out.println(curScenario[idx]);
                audit.setScenarios(new Scenario[]{curScenario[idx]});
                audit.run();
                // fixme print every 3 scenario ?
                if (audit.getRuns() % 3 == 0) {
                    audit.printStatistic();
                    if(idx != curScenario.length - 1 && !continueOrNo(scanner)){
                        break;
                    }
                }
            }
//            for (Scenario scenario : genScenario(cmd)) {
//                System.out.println(scenario);
//                audit.setScenarios(new Scenario[]{scenario});
//                audit.run();
//                // fixme print every 3 scenario ?
//                if (audit.getRuns() % 3 == 0) {
//                    audit.printStatistic();
//                    if( !continueOrNo(scanner)){
//                        break;
//                    }
//                }
//            }
            if (audit.getRuns() % 3 != 0) {
                audit.printStatistic();
            }

            if (cmd.getConfigFile() != null || !continueOrNo(scanner)) {
                System.out.println("That's all. Press Enter to quit.");
                System.in.read();
                return;
            }
        }
    }

    /**
     * @param argv arguments
     * @throws IOException
     */
    public static void main(String[] argv) throws IOException {
        final Argument arg = Argument.load(argv);
        // show welcome
        printWelcome();
        final Scanner scanner = new Scanner(System.in);

        // check config file exists
        if (arg.getConfigFile() != null) {
            File cfgFile = new File(arg.getConfigFile());
            if (!cfgFile.exists() || cfgFile.isDirectory()) {
                System.out.println("ERROR: could not find config file.");
                System.exit(1);
            }
        }

        // print help
        if (arg.isHelp()) {
            System.out.println(Argument.helpInfo());
            return;
        }
        // ask for consent for logging to file
        final boolean saveFile = saveDecisionToFile(scanner);

        Audit audit = new Audit();
        // interactive mode
        if (arg.isInteractiveArg()) {
            interactiveMode(audit, arg, scanner);
        } else {
            audit.setAuditType("auto");
            audit.setDecisionFun(EthicalEngine::decide);
            audit.run(100);
            audit.printStatistic();
        }

        if (saveFile && arg.getResultFile() != null) {
            audit.printToFile(arg.getResultFile());
        }
    }

}




