package ethicalengine;

import java.io.IOException;

/**
 * program setup up arguments
 */
public class Argument {

    final private boolean help;
    final private boolean interactive;
    final private String configFile;
    final private String resultFile;
    private Scenario[] cfg;

    private Argument(boolean help, boolean interactive, String configFile, String resultFile) {
        this.help = help;
        this.interactive = interactive;
        this.configFile = configFile;
        this.resultFile = resultFile;

        try {
            this.cfg = ConfigReader.readFromFile(getConfigFile());
        } catch (Exception e) {

        }
    }

    public Scenario[] getConfig(){
        return cfg;
    }

    public static String helpInfo() {
        return
            "EthicalEngine - COMP90041 - Final Project\n" +
                "Usage: java EthicalEngine [arguments]\n" +
                "Arguments:\n" +
                "\t-c or --config Optional: path to config file\n" +
                "\t-r or --results Optional: path to results log file\n" +
                "\t-h or --help Print Help (this message) and exit\n" +
                "\t-i or --interactive Optional: launches interactive mode";
    }


    private static boolean isHelpArg(String flag) {
        return flag.equalsIgnoreCase("-h") || flag.equalsIgnoreCase("--help");
    }

    private static boolean isInteractiveArg(String flag) {
        return flag.equalsIgnoreCase("-i") || flag.equalsIgnoreCase("--interactive");
    }

    private static boolean isConfigFileArg(String flag) {
        return flag.equalsIgnoreCase("-c") || flag.equalsIgnoreCase("--config");
    }

    private static boolean isResultFileArg(String flag) {
        return flag.equalsIgnoreCase("-r") || flag.equalsIgnoreCase("--results");
    }

    private static boolean isArg(String flag) {
        return isHelpArg(flag) || isInteractiveArg(flag) || isConfigFileArg(flag) || isResultFileArg(flag);
    }

    /**
     * parse use argument
     * @param args
     * @return
     */
    public static Argument load(String[] args) {
        boolean help = false;
        boolean interactive = false;
        String configFile = null;
        String resultFile = null;
        for (int i = 0; i < args.length; i++) {
            if (isHelpArg(args[i])) {
                help = true;
            } else if (isInteractiveArg(args[i])) {
                interactive = true;
            } else if (isConfigFileArg(args[i])) {
                if (i < args.length - 1 && !isArg(args[i + 1])) {
                    configFile = args[i + 1];
                    i++;
                } else {
                    // config path not present
                    help = true;
                }
            } else if (isResultFileArg(args[i])) {
                if (i < args.length - 1 && !isArg(args[i + 1])) {
                    resultFile = args[i + 1];
                    i++;
                } else {
                    // result path not present
                    help = true;
                }
            } else {
                // unknown command
                help = true;
            }
        }
        return new Argument(help, interactive, configFile, resultFile);
    }

    public boolean isHelp() {
        return help;
    }

    public boolean isInteractiveArg() {
        return interactive;
    }

    public String getConfigFile() {
        return configFile;
    }

    public String getResultFile() {
        return resultFile;
    }

    @Override
    public String toString() {
        return "Argument{" +
            "help=" + help +
            ", interactive=" + interactive +
            ", configFile='" + configFile + '\'' +
            ", resultFile='" + resultFile + '\'' +
            '}';
    }


}
