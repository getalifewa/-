package ethicalengine;

public abstract class Character {

    public enum Gender {
        FEMALE, MALE, UNKNOWN
    }

    public enum BodyType {
        AVERAGE, ATHLETIC, OVERWEIGHT, UNSPECIFIED
    }

    private int age = 0;
    private BodyType bodyType = BodyType.UNSPECIFIED;
    private Gender gender = Gender.UNKNOWN;
    private Role role;

    public Character() {
        this(0, Gender.UNKNOWN, BodyType.UNSPECIFIED);
    }

    public Character(int age, Gender gender, BodyType bodyType) {
        this.age = age;
        this.bodyType = bodyType;
        this.gender = gender;
    }

    public Character(Character c) {
        this(c.getAge(), c.getGender(), c.getBodyType());
    }


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public BodyType getBodyType() {
        return bodyType;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setBodyType(BodyType bodyType) {
        this.bodyType = bodyType;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }
}
