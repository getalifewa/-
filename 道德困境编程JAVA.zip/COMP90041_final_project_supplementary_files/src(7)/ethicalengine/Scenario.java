package ethicalengine;

public class Scenario {

    private Character[] passengers;
    private Character[] pedestrians;
    private boolean isLegalCrossing;
    private boolean pedsInLane;


    public Scenario(
        Character[] passengers,
        Character[] pedestrians,
        boolean isLegalCrossing
        ) {
        this.passengers = passengers;
        this.pedestrians = pedestrians;
        this.isLegalCrossing = isLegalCrossing;
        this.pedsInLane = false;
    }

    public Scenario(
            Person[] passengers,
            Person[] pedestrians,
            boolean isLegalCrossing,
            boolean pedsInLane) {
        this.passengers = passengers;
        this.pedestrians = pedestrians;
        this.isLegalCrossing = isLegalCrossing;
        this.pedsInLane = pedsInLane;
    }


    public boolean hasYouInCar() {
        for (Character person : getPassengers()) {
            if (person instanceof Person && ((Person) person).isYou()) {
                return true;
            }
        }
        return false;
    }

    public boolean hasYouInLane() {
        for (Character person : getPedestrians()) {
            if (person instanceof Person && ((Person) person).isYou()) {
                return true;
            }
        }
        return false;
    }

    public Character[] getPassengers() {
        return this.passengers;
    }

    public Character[] getPedestrians() {
        return this.pedestrians;
    }

    public boolean isLegalCrossing() {
        return this.isLegalCrossing;
    }

    public void setLegalCrossing(boolean isLegalCrossing) {
        this.isLegalCrossing = isLegalCrossing;
    }

    public int getPassengerCount() {
        return getPassengers().length;
    }

    public int getPedestrianCount() {
        return getPedestrians().length;
    }

    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder();
        ret.append("======================================\n");
        ret.append("# Scenario\n");
        ret.append("======================================\n");
        ret.append("Legal Crossing: ").append(this.isLegalCrossing ? "yes" : "no").append("\n");
        ret.append("Passengers (").append(getPassengerCount()).append(")").append("\n");
        for (Character passenger : getPassengers()) {
            ret.append("- ").append(passenger.toString()).append("\n");
        }
        ret.append("Pedestrians (").append(getPedestrianCount()).append(")").append("\n");
         for (int i = 0 ;i < pedestrians.length ;i ++) {
            ret.append("- ").append(pedestrians[i].toString());
            if(i != pedestrians.length - 1){
                ret.append("\n");
            }
        }
        return ret.toString();
    }
}
