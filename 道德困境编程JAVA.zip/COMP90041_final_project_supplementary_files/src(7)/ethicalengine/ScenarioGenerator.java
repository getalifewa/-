package ethicalengine;

import java.util.Random;
import ethicalengine.Person.*;
import ethicalengine.Character.*;

/**
 * scenario generator
 */
public class ScenarioGenerator {

    private final Random rand;
    private int passengerCountMin = 1;
    private int passengerCountMax = 5;
    private int pedestrianCountMin = 1;
    private int pedestrianCountMax = 5;

    public ScenarioGenerator() {
        this(System.currentTimeMillis());
    }

    public ScenarioGenerator(long seed) {
        this(seed, 1, 5);
    }

    public ScenarioGenerator(long seed,
                             int passengerCountMinimum,
                             int passengerCountMaximum,
                             int pedestrianCountMinimum,
                             int pedestrianCountMaximun) {
        this.rand = new Random(seed);
        this.passengerCountMin = passengerCountMinimum;
        this.passengerCountMax = passengerCountMaximum;
        this.pedestrianCountMin = pedestrianCountMinimum;
        this.pedestrianCountMax = pedestrianCountMaximun;
    }

    public ScenarioGenerator(long seed,
                             int passengerCountMinimum,
                             int passengerCountMaximum) {
        this(seed, passengerCountMinimum, passengerCountMaximum,
                passengerCountMinimum, passengerCountMaximum);
    }

    public void setPassengerCountMin(int passengerCountMin) {
        this.passengerCountMin = passengerCountMin;
    }

    public void setPassengerCountMax(int passengerCountMax) {
        this.passengerCountMax = passengerCountMax;
    }

    public void setPedestrianCountMin(int pedestrianCountMin) {
        this.pedestrianCountMin = pedestrianCountMin;
    }

    public void setPedestrianCountMax(int pedestrianCountMax) {
        this.pedestrianCountMax = pedestrianCountMax;
    }

    /**
     * generate random profession
     *
     * @return profession
     */
    private Profession randProfession() {
        Profession[] data = new Profession[]{
                Profession.DOCTOR,
                Profession.CEO,
                Profession.CRIMINAL,
                Profession.HOMELESS,
                Profession.UNEMPLOYED,
        };
        return data[rand.nextInt(data.length)];
    }

    /**
     * generate random bodyType
     *
     * @return bodyType
     */
    private BodyType randBodyType() {
        BodyType[] data = new BodyType[]{
                BodyType.AVERAGE,
                BodyType.ATHLETIC,
                BodyType.OVERWEIGHT
        };
        return data[rand.nextInt(data.length)];
    }

    /**
     * generate random person
     *
     * @return person
     */
    public Person getRandomPerson() {
        int age = rand.nextInt(90) ;
        Profession profession = randProfession();
        Gender gender = rand.nextBoolean() ? Gender.MALE : Gender.FEMALE;
        BodyType body = randBodyType();
        boolean pregnant = gender == Gender.FEMALE && rand.nextBoolean();
        return new Person(age, profession, gender, body, pregnant);
    }

    /**
     * generate random animal
     *
     * @return animal
     */
    public Animal getRandomAnimal() {
        String[] data = new String[]{"cat", "dog", "bird", "mouse"};
        return new Animal(data[rand.nextInt(data.length)]);
    }

    /**
     * generate random scenario
     *
     * @return secenario
     */
    public Scenario generate() {
        int passengerSize = rand.nextInt(this.passengerCountMax - this.passengerCountMin) + this.passengerCountMin;
        int pedestrianSize = rand.nextInt(this.pedestrianCountMax - this.pedestrianCountMin) + this.pedestrianCountMin;

        Person[] passengerArray = new Person[passengerSize];
        for (int i = 0; i < passengerSize; i++) {
            passengerArray[i] = this.getRandomPerson();
        }
        Person[] pedestrianArray = new Person[pedestrianSize];
        for (int i = 0; i < pedestrianSize; i++) {
            pedestrianArray[i] = this.getRandomPerson();
        }
        return new Scenario(passengerArray, pedestrianArray,
                rand.nextBoolean(), rand.nextBoolean());
    }


}







