package ethicalengine;

public class Person extends Character {

    public enum AgeCategory {
        BABY, CHILD, ADULT, SENIOR
    }


    public enum Profession {
        DOCTOR, CEO, PROFESSOR, CRIMINAL, HOMELESS, UNEMPLOYED, UNKNOWN, NONE
    }

    private Profession profession = Profession.UNKNOWN;
    private boolean pregnant = false;
    private boolean isYou = false;


    public Person() {

    }

    public Person(int age, Gender gender, BodyType bodyType) {
        this(age, Profession.UNKNOWN, gender, bodyType, false);
    }


    public Person(int age,
                  Gender gender, BodyType bodyType, boolean isPregnant) {
        this(age, Profession.UNKNOWN, gender, bodyType, isPregnant);
    }

    public Person(int age,
                  Profession profession,
                  Gender gender, BodyType bodyType, boolean isPregnant) {
        super(age, gender, bodyType);
        this.profession = profession;
        this.pregnant = isPregnant;
    }

    public Person(Person otherPerson) {
        this(otherPerson.getAge(), otherPerson.getProfession(),
                otherPerson.getGender(), otherPerson.getBodyType(), otherPerson.isPregnant());
    }

    /**
     * get age category
     *
     * @return age category
     */
    public AgeCategory getAgeCategory() {
        if (getAge() >= 0 && getAge() <= 4) {
            return AgeCategory.BABY;
        } else if (getAge() >= 5 && getAge() <= 16) {
            return AgeCategory.CHILD;
        } else if (getAge() >= 17 && getAge() <= 68) {
            return AgeCategory.ADULT;
        } else if (getAge() >= 68) {
            return AgeCategory.SENIOR;
        } else {
            throw new IllegalArgumentException("age invalid");
        }
    }

    public Profession getProfession() {
        if (getAgeCategory() != AgeCategory.ADULT) {
            return Profession.UNKNOWN;
        } else {
            return this.profession;
        }
    }

    public boolean isPregnant() {
        if (getGender() != Gender.FEMALE) {
            return false;
        } else {
            return pregnant;
        }
    }

    public void setPregnant(boolean pregnant) {
        if (getGender() == Gender.FEMALE) {
            this.pregnant = pregnant;
        }
    }

    public boolean isYou() {
        return isYou;
    }

    public void setAsYou(boolean isYou) {
        this.isYou = isYou;
    }

    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder();
        if (isYou()) {
            ret.append("you").append(" ");
        }
        ret.append(getBodyType()).append(" ");
        ret.append(getAgeCategory()).append(" ");
        if(getAgeCategory() == AgeCategory.ADULT){
            ret.append(getProfession()).append(" ");
        }
        ret.append(getGender());
        if (isPregnant()) {
            ret.append(" ").append("pregnant");
        }
        return ret.toString().toLowerCase();
    }

}
