package ethicalengine;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import ethicalengine.Character.*;
import ethicalengine.Person.*;

/**
 * read config from csv file
 */
public class ConfigReader {

    /**
     * number of values illegal
     */
    public static class InvalidDataFormatException extends Exception{

    }

    /**
     * illegal enum value
     */
    public static class InvalidCharacteristicException extends Exception {

    }

    /**
     * parse config file
     * @param configFilePath config file path
     * @return scenarios
     */
    public static Scenario[] readFromFile(String configFilePath) throws IOException {
        List<Scenario> ret = new ArrayList<>();
        try(BufferedReader reader = new BufferedReader(new FileReader(configFilePath))){
            // skip header
            reader.readLine();
            int lineCount = 2;
            String line = null;
            boolean waiting = false;
            boolean legal = false;
            List<Character> passengers = new ArrayList<>();
            List<Character> pedestrains = new ArrayList<>();

            while ((line = reader.readLine()) != null){
                if(line.startsWith("scenario")){
                   if(waiting){
                       ret.add(new Scenario(passengers.toArray(new Character[0]),pedestrains.toArray(new Character[0]),legal));
                       passengers = new ArrayList<>();
                       pedestrains = new ArrayList<>();
                       legal = readScenarioLegal(line);
                   }else{
                       waiting = true;
                       legal = readScenarioLegal(line);
                   }
                }else {
                    try {
                        Character ch = readCharacter(line);
                        if(ch.getRole() == Role.PASSENGER){
                            passengers.add(ch);
                        }else{
                            pedestrains.add(ch);
                        }
                    } catch (InvalidDataFormatException ex) {
                        //System.out.printf("WARNING: invalid data format in %s in line %d\n", configFilePath, lineCount);
                        System.out.printf("WARNING: invalid data format in config file in line %d\n", lineCount);
                    } catch (NumberFormatException ex) {
                        //System.out.printf("WARNING: invalid number format in %s in line %d\n", configFilePath, lineCount);
                        System.out.printf("WARNING: invalid number format in config file in line %d\n", lineCount);
                    } catch (InvalidCharacteristicException ex) {
                        //System.out.printf("WARNING: invalid characteristic in %s in line %d\n", configFilePath, lineCount);
                        System.out.printf("WARNING: invalid number format in config file in line %d\n", lineCount);
                    }
                }
                lineCount +=1;
            }
            if(waiting) {
                ret.add(new Scenario(passengers.toArray(new Character[0]), pedestrains.toArray(new Character[0]), legal));
            }
        }
        return ret.toArray(new Scenario[0]);
    }

    /**
     * is scenario legal crossing
     * @param line scenario line
     * @return is legal crossing
     */
    private static  boolean  readScenarioLegal(String line){
        String[] arr = line.split(":");
        return arr[1].toLowerCase().startsWith("green");
    }

    /**
     * convert string to enum
     * @param clz enum type
     * @param data string data
     * @param defaultValue if data is null
     * @return enum
     * @return enum instance
     * @throws InvalidCharacteristicException
     */
    private static <T extends Enum<T>> T conv(Class<T> clz, String data, String defaultValue) throws InvalidCharacteristicException{
        if(data == null || data.isEmpty()){
            data = defaultValue;
        }
        try{
            return Enum.valueOf(clz,data);
        }catch (Throwable ex){
            throw new InvalidCharacteristicException();
        }
    }

    /**
     * read character from string
     * @param line string line
     * @return charatore
     * @throws InvalidDataFormatException
     * @throws NumberFormatException
     * @throws InvalidCharacteristicException
     */
    private static Character readCharacter(String line) throws InvalidDataFormatException, NumberFormatException, InvalidCharacteristicException {
        String[] rawData = line.split(",", -1);
        if (rawData.length != 10) {
            throw new InvalidDataFormatException();
        }
        String clz = rawData[0];
        Gender gender = conv(Gender.class, rawData[1].toUpperCase(), Gender.UNKNOWN.name());
        int age = Integer.parseInt(rawData[2]);
        BodyType bodyType = conv(BodyType.class, rawData[3].toUpperCase(), BodyType.UNSPECIFIED.name());
        Profession profession = conv(Profession.class, rawData[4].toUpperCase(), Profession.UNKNOWN.name());
        boolean isPregnant = Boolean.parseBoolean(rawData[5]);
        boolean isYou = Boolean.parseBoolean(rawData[6]);
        String species = rawData[7];
        boolean isPet = Boolean.parseBoolean(rawData[8]);
        Role role = conv(Role.class, rawData[9].toUpperCase(),null);
        if (clz.equalsIgnoreCase("person")) {
            Person person = new Person(age, profession, gender, bodyType, isPregnant);
            person.setAsYou(isYou);
            person.setRole(role);
            return person;
        } else {
            Animal animal = new Animal(species);
            animal.setGender(gender);
            animal.setRole(role);
            animal.setAge(age);
            animal.setBodyType(bodyType);
            animal.setPet(isPet);
            return animal;
        }
    }

}
