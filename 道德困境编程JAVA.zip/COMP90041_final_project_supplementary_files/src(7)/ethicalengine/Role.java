package ethicalengine;

public enum Role {
    PASSENGER, PEDESTRIAN
}
