package ethicalengine;

public class Animal extends Character {

    private String species;
    private boolean isPet = false;

    public Animal(){
        super(0, Gender.UNKNOWN, BodyType.UNSPECIFIED);
    }

    /**
     * constructor
     * @param species animal species
     */
    public Animal(String species) {
        super(0, Gender.UNKNOWN, BodyType.UNSPECIFIED);
        this.species = species;
    }

    /**
     * copy constructor
     * @param otherAnimal
     */
    public Animal(Animal otherAnimal) {
        this(otherAnimal.getSpecies());
    }

    public String getSpecies() {
        return this.species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public boolean isPet() {
        return isPet;
    }

    public void setPet(boolean pet) {
        isPet = pet;
    }

    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder();
        ret.append(getSpecies());
        if (isPet()) {
            ret.append(" ").append("is pet");
        }
        return ret.toString().toLowerCase();
    }
}
