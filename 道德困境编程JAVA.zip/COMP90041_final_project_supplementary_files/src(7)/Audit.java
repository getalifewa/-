import ethicalengine.*;
import ethicalengine.Character;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.function.Function;

public class Audit {

    private final TreeMap<String, AuditItem> data = new TreeMap<>();
    private String auditType = "Unspecified";
    private int runs = 0;
    private Scenario[] scenarios = new Scenario[0];
    private int totalAge = 0;
    private int totalCount = 0;
    // decide algorithm
    private Function<Scenario, EthicalEngine.Decision> decisionFun;

    public Audit() {

    }


    public Audit(Scenario[] scenarios) {
        this.scenarios = scenarios;
    }

    /**
     * run simulation with specified scenarios
     */
    public void run() {
        runWithScenarios(this.scenarios);
    }

    /**
     * helper function, run scenario and update statistic data
     * @param scenarios  scenario array
     */
    private void runWithScenarios(Scenario[] scenarios) {
        for (Scenario scenario : scenarios) {
            EthicalEngine.Decision result = getDecisionFun().apply(scenario);
            record(scenario.getPedestrians(), scenario.isLegalCrossing(), result == EthicalEngine.Decision.PEDESTRIANS);
            record(scenario.getPassengers(), scenario.isLegalCrossing(), result == EthicalEngine.Decision.PASSENGERS);
            runs++;
        }
    }

    /**
     * help function
     * @param characters character array
     * @param legal is cross legal
     * @param live dead or alive
     */
    private void record(Character[] characters, boolean legal, boolean live) {
        for (Character item : characters) {
            record(item, legal, live);
        }
    }

    /**
     * update statistic data
     * @param character character
     * @param legal is cross legal
     * @param live dead or alive
     */
    private void record(Character character, boolean legal, boolean live) {
        
        data.computeIfAbsent(legal ? "green" : "red", k -> new AuditItem()).acc(live);
        if (character instanceof Animal) {
            data.computeIfAbsent("animal", k -> new AuditItem()).acc(live);
            data.computeIfAbsent(((Animal) character).getSpecies(), k -> new AuditItem()).acc(live);
            if(((Animal) character).isPet()) {
                data.computeIfAbsent("pet", k -> new AuditItem()).acc(live);
            }
        } else if (character instanceof Person) {
            Person person = (Person) character;

            if(live){
                totalAge += character.getAge();
                totalCount += 1;
            }

            data.computeIfAbsent("person", k -> new AuditItem()).acc(live);
            if(person.getAgeCategory() == Person.AgeCategory.ADULT){
                data.computeIfAbsent(person.getProfession().name().toLowerCase(), k -> new AuditItem()).acc(live);
            }
            data.computeIfAbsent(person.getGender().name().toLowerCase(), k -> new AuditItem()).acc(live);
            data.computeIfAbsent(person.getBodyType().name().toLowerCase(), k -> new AuditItem()).acc(live);
            data.computeIfAbsent(person.getAgeCategory().name().toLowerCase(), k -> new AuditItem()).acc(live);
            if (person.isPregnant()) {
                data.computeIfAbsent("pregnant", k -> new AuditItem()).acc(live);
            }
            if (person.isYou()) {
                data.computeIfAbsent("you", k -> new AuditItem()).acc(live);
            }
        }
    }

    /**
     * run simulate with generated scenario
     * @param runs run times
     */
    public void run(int runs) {
        Scenario[] data = new Scenario[runs];
        for (int i = 0; i < data.length; i++) {
            data[i] = new ScenarioGenerator().generate();
        }
        this.runWithScenarios(data);
    }

    public String getAuditType() {
        return this.auditType;
    }

    /**
     * set audit name
     * @param name name of audit type
     */
    public void setAuditType(String name) {
        this.auditType = name;
    }

    /**
     * get run times
     * @return run times
     */
    public int getRuns() {
        return this.runs;
    }

    static String clipDouble(double value){
        return  BigDecimal.valueOf(value).setScale(1, RoundingMode.FLOOR).toPlainString();
    }

    @Override
    public String toString() {
        if (getRuns() == 0) {
            return "no audit available";
        }
        StringBuilder ret = new StringBuilder();
        ret.append("======================================\n");
        ret.append("# User Audit\n");
        ret.append("======================================\n");
        ret.append("- % SAVED AFTER ").append(getRuns()).append(" RUNS\n");

        List<Map.Entry<String, AuditItem> > temp = new ArrayList<>( data.entrySet());
        temp.sort((o1, o2) -> {
            int cmp = o2.getValue().clipRate().compareTo(o1.getValue().clipRate());
            return cmp == 0 ? o1.getKey().compareTo(o2.getKey()): cmp;
        });

        for (Map.Entry<String, AuditItem> pair : temp) {
            ret.append(String.format("%s: %s\n", pair.getKey(),
                clipDouble(pair.getValue().rate()))
            );
        }
        ret.append("--\n");
        ret.append(String.format("average age: %s", clipDouble(totalAge * 1.0 / totalCount)));
        return ret.toString();
    }

    /**
     * save statistic data to file
     * @param path file path
     * @throws IOException
     */
    public void printToFile(String path) throws IOException {
        if(path == null || path.isEmpty()) {
            System.out.println("ERROR: could not print results. Target directory does not exist.");
            return;
        }
        File parentFile = new File(path).getParentFile();
        if (parentFile != null && !parentFile.exists()) {
            System.out.println("ERROR: could not print results. Target directory does not exist.");
            return;
        }
        try (FileWriter writer = new FileWriter(path, true)) {
            writer.write(toString());
        }
    }

    public Function<Scenario, EthicalEngine.Decision> getDecisionFun() {
        return decisionFun;
    }

    public void setDecisionFun(Function<Scenario, EthicalEngine.Decision> decisionFun) {
        this.decisionFun = decisionFun;
    }

    /**
     * print statistic data to console
     */
    public void printStatistic() {
        System.out.println(toString());
    }

    public void setScenarios(Scenario[] scenarios) {
        this.scenarios = scenarios;
    }

    /**
     * helper class for statistic
     */
    private static class AuditItem {
        private int count = 0;
        private int total = 0;

        public void acc(boolean live) {
            if (live) {
                this.count++;
            }
            total++;
        }

        public String clipRate(){
            return clipDouble(rate());
        }
        public double rate() {
            return (1.0 * count) / total;
        }

    }
}
